//
//  ViewController.swift
//  NSTimerDemo
//
//  Created by Mac on 7/23/18.
//  Copyright © 2018 agile. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var lblCounter: UILabel!
     var counter =  0
    var timer = Timer()
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
    }

    @IBAction func btnStart(_ sender: UIButton)
    {
        timer.invalidate()
        timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(timerAction), userInfo: nil, repeats: true)
        
    }
    
    @IBAction func btnStop(_ sender: UIButton)
    {
        timer.invalidate()
        
        
        
    }
    
    @objc func timerAction()
    {
        counter += 1
        lblCounter.text = "\(counter)"
        print("Counter:\(counter)")
    }
    
}

